export default {
    nodeapipath:"http://localhost:9000/"
}