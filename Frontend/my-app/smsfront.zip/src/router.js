import {
  createBrowserRouter
} from "react-router-dom";
import App from "./Components/App";
import AddLibrary from "./Components/AddLibrary";
import AddGroup from "./Components/AddGroup";
import AddMessage from "./Components/AddMessage";
import AddContact from "./Components/AddContact";
import Home from "./Components/Home";


const router = createBrowserRouter([
  {
    path: "/",
    element: <App></App>,
    children: [
      {
        path: '/',
        element: <Home />
      },
      {
        path: 'add_lib',
        element: <AddLibrary />
      },
      {
        path: 'add_grp',
        element: <AddGroup/>
      },
      {
        path: 'add_msg',
        element: <AddMessage />
      },
      {
        path: 'add_contact',
        element: <AddContact />
      },

    ]
  },
]);

export default router;