import React from 'react'
import { useForm } from "react-hook-form"
import dataprocess from '../function/dataprocess';


export default function AddLibrary() {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const onSubmit = (data) => {console.log(data)
  
    if (data != "") {
      dataprocess("library/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      })
        .then((res) => {
          console.log(res);
        })
        .catch((err)=>{
          console.log(err);
        })
    }

  };
  

  return (
    <div className='container border border-primary-subtle'>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label>Add Library</label>
        <input type=" text" className='form-control' {...register("lib_name", { required: true })} /><br />
        {errors.lib_name?.type === "required" && (
          <p role="alert">Library name required</p>
        )}
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  )
}
