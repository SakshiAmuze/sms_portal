import React from 'react';
import { useForm } from "react-hook-form"
import dataprocess from '../function/dataprocess';

export default function AddGroup() {
  const { register, handleSubmit,formState: { errors } } = useForm();
  const onSubmit = (data) => {console.log(data)
  
    if (data != "") {
      dataprocess("group/add-grp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      })
        .then((res) => {
          console.log(res);
        })
        .catch((err)=>{
          console.log(err);
        })
    }
  };
  return (
    <div className='container border border-primary-subtle'>
    <form onSubmit={handleSubmit(onSubmit)}>
      <label>Add Group</label>
      <input type=" text" className='form-control' {...register("grp_name",{ required: true})}/><br/>
      {errors.grp_name?.type === "required" && (
          <p role="alert">Group name required</p>
        )}
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>
  )
}
