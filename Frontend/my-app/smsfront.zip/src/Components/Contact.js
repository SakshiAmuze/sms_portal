import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import useFetch from '../Functions/useFetch';
import { sendGrpDataToPanel } from '../redux/reducers/groupSlice';

export default function Contact() {
    const dispatch = useDispatch()
    var ansById = useSelector(state=>state.group.grpname);
    console.log(ansById);

    var path = "contact/show-contact-By-Id/"+ ansById;
    console.log(path);

    var ans = useFetch(path);
    console.log(ans);

    function myfunc(value){
      console.log(value);
      dispatch(sendGrpDataToPanel(value))
    }
  return (
    <section className='contact-section'>
                    <h4 className='text-center p-4'>Contact</h4>
                    <div className='border'>
                    <ul>
                    {
                        ans.data &&  ans.data.length > 0 && ans.data.map(val =>
                            <li onClick={(ev) => { myfunc(ev.target.innerText) }}>{val.username}</li>
                        )
                    }
                </ul>    
                    </div>


                </section>
  )
}
