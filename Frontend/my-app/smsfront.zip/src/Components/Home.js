import React from 'react'
import Library from './Library'
import Message from './Message'
import Group from './Group'
import Contact from './Contact'
import { useSelector } from 'react-redux'

export default function Home() {
    var contact = useSelector(state=>state.group.contact)
    console.log(contact);
  return (

    <div className='container'>
    <h1 className='text-center p-4'>Send SMS</h1>
    <div className='row'>
        <div className='col-4'>
            <Library></Library>
            <Message></Message>
        </div>
        <div className='col-4'>
            
            <form>
                <input type='text' defaultvalue={contact}/><br />
                <input type='text' /> <br />
                <input type='text' /> <br />
                <textarea ></textarea><br/>
                <button>Send SMS</button>
            </form>
        </div>
        <div className='col-4'>
            
            <Group></Group>
            <Contact></Contact>
        </div>
    </div>
</div>
    )
}
